import census_geocoder
import json


address_list = []
###
test1 = {
    'street' : '333 Mrkt St',
    'city' : 'Harrisburg',
    'state' : 'PA'
}
###
test2 = {
    'street' : '101 W Court Street',
    'city' : 'Greenville',
    'state' : 'SC',
    'zip' : '29601',
}
###
test3 = {
    'street' : '3713 Covenant Rd',
    'city' : 'Columbia',
    'state' : 'SC',
    'zip' : '29204',
}
###
test4 = {
    'street' : '209 S College St',
    'city' : 'Heath Springs',
    'state' : 'SC',
    'zip' : '29058',    
}

# test_address = test4

test_address = {
    'street' : '1600 Pennsylvania Avenue',
    'city' : 'Washington',
    'state' : 'DC',
    # 'zip' : '20500', zip is optional 
}
my_geocoder = census_geocoder.Geocoder(
    street = test_address['street'], 
    city = test_address['city'],
    state = test_address['state'],
    # zip_code = test_address['zip'], ### zip is optional
    # layers = ['14', '16', '18', '54', '56', '58'], ### default layers included in geography output for a geocoded address; 
    # layers = ['86'] ### if you only wanted counties in the .geographies object
    layers = census_geocoder.ALL_AVAILABLE_LAYERS, ### shortcut to get all available layers - 
)

# print(my_geocoder.available_geography_layers()) ### print all available layers from settings

my_geocoder.geocode() # call the geocoding services; 

print(my_geocoder.matched_address, my_geocoder.latitude, my_geocoder.longitude, '\n')
print(json.dumps(my_geocoder.geographies, indent=4))
